# sample_vehicle_launch
